import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TrafficViolationTest {

    @Test
    public void test() {
        assertEquals("aaa", "aaa");
    }

}
